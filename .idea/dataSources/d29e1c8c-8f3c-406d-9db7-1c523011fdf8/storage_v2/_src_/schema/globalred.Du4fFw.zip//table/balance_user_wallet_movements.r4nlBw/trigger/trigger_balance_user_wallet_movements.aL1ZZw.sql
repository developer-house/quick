create definer = admin@`%` trigger trigger_balance_user_wallet_movements
    before update
    on balance_user_wallet_movements
    for each row
begin

    -- Validamos si el movimiento fue aprobado
    if NEW.state_id = 16 then

        begin

            -- UPDATE balance_user_wallets SET balance_paid = (balance_paid + NEW.value) WHERE id = NEW.wallet_id;

        end;

    end if;

end;

