create definer = admin@`%` trigger transfer_commission_to_user_balances_insert_trigger
    after insert
    on transfer_commission_to_user_balances
    for each row
begin

    declare b decimal(15, 2);
    set b = (select balance from balance_users where user_id = NEW.user_id);

    -- Sumamos el saldo al usuario seleccionado
    update balance_users set balance = balance + NEW.value_to_transfer where user_id = NEW.user_id;

    -- Restamos la comisión trasferida
    UPDATE user_commissions SET commission = commission - NEW.value_to_transfer WHERE user_id = NEW.user_id;

    -- Registramos la trasferencia en la tabla de movimientos de los usuarios
    insert into balance_user_movements (author_id, user_id, author_asistente, previous_balance, balance_to_recharge, new_balance, support,
                                        movement_id, transfer_commission_to_user_balance_id, created_at, updated_at)
    values (NEW.author_id, NEW.author_id, NEW.user_id, b, NEW.value_to_transfer, (b + NEW.value_to_transfer), '', 28, NEW.id,
            NEW.created_at,
            NEW.updated_at);

end;

