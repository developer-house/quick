create definer = admin@`%` trigger balance_user_temporary_insert_trigger
    before insert
    on balance_user_temporary
    for each row
begin

    declare b decimal(15, 2);
    set b = (select balance from balance_users where user_id = NEW.user_id);

    -- Sumamos el saldo al usuario seleccionado
    update balance_users set balance = balance + NEW.balance where user_id = NEW.user_id;

    -- Restamos el saldo que agregamos al usuario seleccionado al usuario que realizó la operación
    update balance_users set balance = balance - NEW.balance where user_id = NEW.author_id;

    -- Registramos la recarga (Recarga o cartera) en la tabla de movimientos de los usuarios
    -- Registramos la recarga (Recarga o cartera) en la tabla de movimientos de los usuarios
    insert into balance_user_movements (id, author_id, author_asistente, user_id, previous_balance, balance_to_recharge, new_balance, support, movement_id, transfer_commission_to_user_balance_id, created_at, updated_at)
    values (null, NEW.author_id, NEW.author_asistente, NEW.user_id, b, NEW.balance, (b + NEW.balance), NEW.support, NEW.movement_id, null, NEW.created_at, NEW.updated_at);

    -- Validamos si la recarga es un préstamo o cartera
    -- 22 = Cartera
    if NEW.movement_id = 22 then

        begin

            declare str_wallet decimal(15, 2);
            set str_wallet = (select wallet from balance_user_wallets where user_id = NEW.user_id);

            -- Sumamos la cartera nueva al usuario seleccionado
            update balance_user_wallets set wallet = wallet + NEW.balance where user_id = NEW.user_id;


            -- Registramos EL movimiento
            insert into balance_user_wallet_movements (id, author_id, author_asistente, user_id, previous_wallet, balance_to_be_paid, new_wallet, support, state_id, movement_id, description, created_at, updated_at)
                value (null, NEW.author_id, NEW.author_asistente, NEW.user_id, str_wallet, NEW.balance, (str_wallet + NEW.balance), NEW.support, 16, 83, null, NEW.created_at, NEW.updated_at);

        end;

    end if;

end;

