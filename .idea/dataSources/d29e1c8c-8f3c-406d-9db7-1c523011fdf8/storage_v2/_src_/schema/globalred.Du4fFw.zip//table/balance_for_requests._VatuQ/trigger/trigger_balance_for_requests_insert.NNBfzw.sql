create definer = admin@`%` trigger trigger_balance_for_requests_insert
    after insert
    on balance_for_requests
    for each row
begin

    insert into audit_balance_for_requests (id, user_id, leader_id, bank_id, deposit_support, deposit_value, author_id,
                                            state_id, user_id_who_approves, db_method, created_at, updated_at)
    values (null, new.user_id, new.leader_id, new.bank_id, new.deposit_support, new.deposit_value, new.author_id,
            new.state_id, new.user_id_who_approves, 'insert', new.created_at, new.updated_at);

end;

