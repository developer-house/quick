create definer = root@localhost trigger audit_update
    after update
    on credits
    for each row
begin

    insert into audit_credits (id, user_id, type_of_credit_id, type_of_modality_id, value, state_id, writing_number,
                               country_id, department_id, city_id, address, requested_value, annual_current_interest,
                               monthly_current_interest, time, initial_date, final_date, cadastral_valuation,
                               interest_moratorium, author_id, action, created_at, updated_at)
    values (null, new.user_id, new.type_of_credit_id, new.type_of_modality_id, new.value, new.state_id,
            new.writing_number, new.country_id, new.department_id, new.city_id, new.address, new.requested_value,
            new.annual_current_interest, new.monthly_current_interest, time, new.initial_date, new.final_date,
            new.cadastral_valuation, new.interest_moratorium, new.author_id, 'update', new.created_at, new.updated_at);

end;

