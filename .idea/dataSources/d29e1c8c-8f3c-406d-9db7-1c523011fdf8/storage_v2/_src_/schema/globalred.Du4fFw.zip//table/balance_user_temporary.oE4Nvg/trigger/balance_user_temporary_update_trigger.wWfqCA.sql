create definer = admin@`%` trigger balance_user_temporary_update_trigger
    before update
    on balance_user_temporary
    for each row
begin

    -- Validamos si restamos saldo por retracción
    -- 29 = retracción
    if NEW.movement_id = 29 then

        begin

            declare leader_balance decimal(15, 2);
            set leader_balance = (select balance from balance_users where user_id = (select leader_id from leader_users where user_id = NEW.user_id));

            update balance_users set balance = balance + NEW.balance where user_id = (select leader_id from leader_users where user_id = NEW.user_id);

            -- restamos el saldo al usuario seleccionado
            update balance_users set balance = balance - NEW.balance where user_id = NEW.user_id;

            insert into balance_user_movements (id, author_id, author_asistente, user_id, previous_balance, balance_to_recharge, new_balance, support, movement_id, transfer_commission_to_user_balance_id, created_at, updated_at)
            values (null, NEW.user_id, NEW.user_id, (select leader_id from leader_users where user_id = NEW.user_id), leader_balance, NEW.balance, (leader_balance + NEW.balance),null, NEW.movement_id, null, NEW.created_at, NEW.updated_at);


        end;



    end if;

    -- Validamos si restamos saldo por venta de producto
    -- 30 = Restar
    if NEW.movement_id = 30 then

        -- restamos el saldo al usuario seleccionado
        update balance_users set balance = balance - NEW.balance where user_id = NEW.user_id;

    end if;
    
    -- Validamos si es pago de cartera
    -- 84 = Pago de cartera
    if NEW.movement_id = 84 then

        begin

            declare str_wallet decimal(15, 2);
            set str_wallet = (select wallet from balance_user_wallets where user_id = NEW.user_id);

            -- Restamos la cartera nueva al usuario seleccionado
            update balance_user_wallets set wallet = wallet - NEW.balance where user_id = NEW.user_id;

            -- Registramos el movimiento
            insert into balance_user_wallet_movements (id, author_id, author_asistente, user_id, previous_wallet, balance_to_be_paid,new_wallet, support, state_id, movement_id, description,created_at, updated_at)
                value (null, NEW.author_id, NEW.author_asistente, NEW.user_id, str_wallet, NEW.balance, (str_wallet - NEW.balance), NEW.support, 16, 84, null, NEW.created_at, NEW.updated_at);

        end;

    end if;


	-- Validamos si es una recarga por pago de premio
    -- 85 = Recarga por pago de premio
    if NEW.movement_id = 85 then

        begin

            declare saldo decimal(15, 2);
            set saldo = (select balance from balance_users where user_id = NEW.user_id);

            -- Sumamos el saldo al usuario seleccionado
            update balance_users set balance = balance + NEW.balance where user_id = NEW.user_id;

            -- Registramos el movimiento
            insert into balance_user_movements (id, author_id, author_asistente, user_id, previous_balance, balance_to_recharge, new_balance, support, movement_id, transfer_commission_to_user_balance_id, created_at, updated_at)
            values (null, NEW.author_id, NEW.author_asistente, NEW.user_id, saldo, NEW.balance, (saldo + NEW.balance), NEW.support, NEW.movement_id, null, NEW.created_at, NEW.updated_at);

        end;

    end if;

end;

