create definer = admin@`%` trigger sales_update_trigger
    before update
    on sales
    for each row
begin

    if NEW.state_id = 72 then

        begin

            declare sale_balance decimal(15, 2);
            set sale_balance = (select balance from balance_users where user_id = NEW.user_id);

            -- Disminuimos el saldo de la venta al usuario
            update balance_users set balance = sale_balance - NEW.value where user_id = NEW.user_id;

            insert into user_balance_for_sale (id, user_id, venta_id, value, balance, new_balance, created_at, updated_at)
                value (null, new.user_id, new.id, new.value, sale_balance, sale_balance - new.value, NEW.created_at,
                       new.updated_at);

        end;


    end if;

end;

