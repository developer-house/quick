create definer = admin@`%` trigger trigger_audit_banks_update
    after update
    on banks
    for each row
begin

    insert into audit_banks (id, name, description, provider_id, type_of_bank_account_id, state_id, account_number,
                             db_method, author_id, created_at, updated_at)
    values (null, new.name, new.description, new.provider_id, new.type_of_bank_account_id, new.state_id,
            new.account_number, 'update', new.author_id, new.created_at, new.updated_at);

end;

