create definer = admin@`%` trigger trigger_products_enableds_insert
    after insert
    on products_enableds
    for each row
begin

    insert into audit_products_enableds (id, product_id, user_id, state_id, author_id, description, created_at,
                                         updated_at)
    values (null, new.product_id, new.user_id, new.state_id, new.author_id, new.description, new.created_at,
            new.updated_at);

end;

