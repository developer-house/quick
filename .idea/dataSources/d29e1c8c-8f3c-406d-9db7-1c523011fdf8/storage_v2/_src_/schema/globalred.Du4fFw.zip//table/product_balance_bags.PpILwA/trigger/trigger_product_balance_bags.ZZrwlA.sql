create definer = admin@`%` trigger trigger_product_balance_bags
    before update
    on product_balance_bags
    for each row
begin

    IF NEW.type_of_operation_id = 26 THEN

        insert into product_balance_bag_movements (id, author_id, product_balance_bag_id, previous_balance,
                                                   balance_to_recharge, new_balance, support, description, created_at,
                                                   updated_at)
        values (NULL,
                new.author_id,
                new.id,
                old.balance,
                (NEW.balance - OLD.balance),
                (OLD.balance + (NEW.balance - OLD.balance)),
                new.support,
                new.description,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP());

    end if;


end;

