create definer = admin@`%` trigger trigger_balance_for_requests_update
    after update
    on balance_for_requests
    for each row
begin


    insert into audit_balance_for_requests (id, user_id, leader_id, bank_id, deposit_support, deposit_value, author_id,
                                            state_id, user_id_who_approves, db_method, created_at, updated_at)
    values (null, new.user_id, new.leader_id, new.bank_id, new.deposit_support, new.deposit_value, new.author_id,
            new.state_id, new.user_id_who_approves, 'update', new.created_at, new.updated_at);

    -- Validamos si la solicitud fue aprobada fue aprobado
    if NEW.state_id = 69 then

        begin

            declare b decimal(15, 2);
            set b = (select balance from balance_users where user_id = NEW.user_id);

            -- Sumamos el saldo al usuario seleccionado
            update balance_users set balance = balance + NEW.deposit_value where user_id = NEW.user_id;

            -- Restamos el saldo que agregamos al usuario seleccionado al usuario que realizó la operación
            update balance_users set balance = balance - NEW.deposit_value where user_id = NEW.leader_id;

            -- Registramos la recarga (Recarga o cartera) en la tabla de movimientos de los usuarios
            insert into balance_user_movements (id, author_id, user_id, previous_balance, balance_to_recharge,
                                                new_balance, support, movement_id,
                                                transfer_commission_to_user_balance_id, created_at, updated_at)
            values (null, NEW.leader_id, NEW.user_id, b, NEW.deposit_value, (b + NEW.deposit_value),
                    NEW.deposit_support, 71, null, NEW.created_at,
                    NEW.updated_at);

        end;

    end if;

end;

