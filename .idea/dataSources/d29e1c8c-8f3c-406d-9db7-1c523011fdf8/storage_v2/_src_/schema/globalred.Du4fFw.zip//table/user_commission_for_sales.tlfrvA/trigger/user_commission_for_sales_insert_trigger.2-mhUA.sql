create definer = admin@`%` trigger user_commission_for_sales_insert_trigger
    before insert
    on user_commission_for_sales
    for each row
begin

    update user_commissions set commission = commission + new.commission where user_id = new.user_id;

end;

